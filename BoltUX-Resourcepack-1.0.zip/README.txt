BoltUX Resourcepack by ShermansWorld - VERSION 1.0 - 2/23/2025

Resource pack includes:
- lock texture
- lock model

This is an optional resource pack add-on to the BoltUX plug-in, authored by ShermansWorld and licensed under the MIT License.
You do not need to request permission to modify this resource pack, or include its contents in any other resource packs.
